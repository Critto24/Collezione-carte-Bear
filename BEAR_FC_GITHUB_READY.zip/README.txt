BEAR FC - GitHub Ready

Carica l'intera cartella su GitHub mantenendo la cartella images.
Il file principale è index.html.

Per GitHub Pages: Settings > Pages > Deploy from branch > main > / (root).
